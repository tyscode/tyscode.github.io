import sys
import pygame
import random


def point():
    tl = [str(i) for i in range(1, 26)]
    tl = list(set(tl))
    for j in range(25):
        tl[j] = int(tl[j])
    return tl

def print_image():
    pygame.init()
    screen = pygame.display.set_mode((500, 500))
    pygame.display.set_caption('point')
    icon = pygame.image.load('./images/1.jpg')
    pygame.display.set_icon(icon)
    i = 0
    temp = point()
    for k in temp:
        image_filename = './images/'+str(k)+'.jpg'
        image = pygame.image.load(image_filename)
        screen.blit(image, (100 * (i % 5), 100 * (i // 5)))
        i += 1
    tei = 1
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if tei == 1:
                    begin = pygame.time.get_ticks()
                mouse_x, mouse_y = pygame.mouse.get_pos()
                i_pos = (mouse_x // 100) + 5 * (mouse_y // 100)
                if temp[i_pos] == tei:
                    tei += 1
                    blank = pygame.image.load('./images/blank.jpg')
                    screen.blit(blank, (100 * (i_pos % 5), 100 * (i_pos // 5)))
                    if tei == 26:
                        end = pygame.time.get_ticks()
                        my_font1 = pygame.font.Font(None, 30)
                        my_font2 = pygame.font.Font(None, 30)
                        text_image1 = my_font1.render((str((end - begin) / 1000)+'s'), True, (0, 0, 0))
                        text_image2 = my_font2.render('press any key to restart', True, (0, 0, 0))
                        screen.blit(text_image1, (200, 170))
                        screen.blit(text_image2, (130, 230))
                        return
            pygame.display.update()


def main():
    m_check = True
    while m_check:
        print_image()
        m_check = False
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    m_check = True
                    break
                pygame.display.update()
            if m_check:
                pygame.display.update()
                break
        main()


main()
